﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using ClosedXML.Excel;

namespace WpfExcelClosedXML
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Student> students;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoadExcel_Click(object sender, RoutedEventArgs e)
        {
            
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*",
                Title = "Load Excel File"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                using (var workbook = new XLWorkbook(openFileDialog.FileName))
                {
                    var worksheet = workbook.Worksheets.Worksheet(1); 
                    var rowCount = worksheet.LastRowUsed().RowNumber();
                    students = new List<Student>();

                    for (int row = 2; row <= rowCount; row++) 
                    {
                        var student = new Student
                        {
                            ID = worksheet.Cell(row, 1).GetValue<int>(),
                            Name = worksheet.Cell(row, 2).GetString(),
                            Sub1 = worksheet.Cell(row, 3).GetValue<int>(),
                            Sub2 = worksheet.Cell(row, 4).GetValue<int>(),
                            Sub3 = worksheet.Cell(row, 5).GetValue<int>(),
                            Sub4 = worksheet.Cell(row, 6).GetValue<int>()
                        };
                        students.Add(student);
                    }

                    dataGrid.ItemsSource = students;
                }
            }
        }

        private void SaveExcel_Click(object sender, RoutedEventArgs e)
        {
           
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Excel Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*",
                Title = "Save Excel File"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("Students");
                    worksheet.Cell(1, 1).Value = "ID";
                    worksheet.Cell(1, 2).Value = "Name";
                    worksheet.Cell(1, 3).Value = "Sub1";
                    worksheet.Cell(1, 4).Value = "Sub2";
                    worksheet.Cell(1, 5).Value = "Sub3";
                    worksheet.Cell(1, 6).Value = "Sub4";
                    worksheet.Cell(1, 7).Value = "Total";

                    for (int i = 0; i < students.Count; i++)
                    {
                        worksheet.Cell(i + 2, 1).Value = students[i].ID;
                        worksheet.Cell(i + 2, 2).Value = students[i].Name;
                        worksheet.Cell(i + 2, 3).Value = students[i].Sub1;
                        worksheet.Cell(i + 2, 4).Value = students[i].Sub2;
                        worksheet.Cell(i + 2, 5).Value = students[i].Sub3;
                        worksheet.Cell(i + 2, 6).Value = students[i].Sub4;
                        worksheet.Cell(i + 2, 7).Value = students[i].Total;
                    }

                    workbook.SaveAs(saveFileDialog.FileName);
                }

                MessageBox.Show("Excel 파일이 저장되었습니다.");
            }
        }

        private void Sum_Click(object sender, RoutedEventArgs e)
        {
            if (students != null)
            {                
                foreach (var student in students)
                {
                    student.CalculateTotalScore();
                }
                
                dataGrid.ItemsSource = null; 
                dataGrid.ItemsSource = students; 
            }
        }
    }
}
