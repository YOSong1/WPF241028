﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfExcelClosedXML
{

    public class Student : INotifyPropertyChanged
    {
        private int sub1;
        private int sub2;
        private int sub3;
        private int sub4;

        public int ID { get; set; }
        public string Name { get; set; }

        public int Sub1
        {
            get => sub1;
            set
            {
                sub1 = value;
                OnPropertyChanged(nameof(Sub1));
            }
        }

        public int Sub2
        {
            get => sub2;
            set
            {
                sub2 = value;
                OnPropertyChanged(nameof(Sub2));
            }
        }

        public int Sub3
        {
            get => sub3;
            set
            {
                sub3 = value;
                OnPropertyChanged(nameof(Sub3));
            }
        }

        public int Sub4
        {
            get => sub4;
            set
            {
                sub4 = value;
                OnPropertyChanged(nameof(Sub4));
            }
        }
        
        private int total;
        public int Total
        {
            get => total;
            private set
            {
                total = value;
                OnPropertyChanged(nameof(Total));
            }
        }

        
        public void CalculateTotalScore()
        {
            Total = Sub1 + Sub2 + Sub3 + Sub4;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

}
