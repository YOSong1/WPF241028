﻿using System.Windows;
using System.Windows.Controls;
using WpfTabControl.ViewModel;
using WpfTabControl.Model;

namespace WpfTabControl.View
{
    /// <summary>
    /// Page3.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Page3 : Page
    {
        public Page3()
        {
            InitializeComponent();
        }

        private void Add_member(object sender, RoutedEventArgs e)
        {
            Person member = new Person()
            {
                ID = id.Text,
                Password = pw.Text,
                Name = name.Text,
                Phone = phone.Text,
                Gender = "M"
            };

            PersonService personService = new PersonService();
            personService.insertMember(member);

            MessageBox.Show("ID : " + id.Text + " Namd : " + name.Text + " Phone : " + phone.Text + " 정보 입력이 완료되었습니다. ");

            id.Text = "";
            pw.Text = "";
            name.Text = "";
            phone.Text = "";
            
        }
    }
}
