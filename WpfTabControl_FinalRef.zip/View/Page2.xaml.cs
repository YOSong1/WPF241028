﻿using System.Windows;
using System.Windows.Controls;
using WpfTabControl.ViewModel;
using WpfTabControl.Model;

namespace WpfTabControl.View
{
    /// <summary>
    /// Page2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Page2 : Page
    {
        public Page2()
        {
            InitializeComponent();
            PersonService personService = new PersonService();
            personService.initMember();
            System.Collections.ObjectModel.ObservableCollection<Person> member = personService.selectMember();

            memberList.ItemsSource = member;
        }

        Person selectedPerson = null;
        private void memberList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedPerson = memberList.SelectedItem as Person;

            if (selectedPerson != null)
            {
                id_up.Text = selectedPerson.ID;
                pw_up.Text = selectedPerson.Password;
                name_up.Text = selectedPerson.Name;
                phone_up.Text = selectedPerson.Phone;
            }
            else
            {
                id_up.Text = "";
                pw_up.Text = "";
                name_up.Text = "";
                phone_up.Text = "";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            selectedPerson.ID = id_up.Text;
            selectedPerson.Password = pw_up.Text;
            selectedPerson.Name = name_up.Text;
            selectedPerson.Phone = phone_up.Text;

            id_up.Text = "";
            pw_up.Text = "";
            name_up.Text = "";
            phone_up.Text = "";

            //MessageBox.Show(selectedPerson.Phone);
        }
    }
}
