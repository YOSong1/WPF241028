﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Reflection.Emit;

namespace WpfLiveChart
{
    /// <summary>
    /// DataGridChart2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DataGridChart2 : Window
    {
        public ObservableCollection<Student> Students { get; set; }
        public ChartValues<double> ChartValues { get; set; }
        public List<string> XLabels { get; set; }  // X축 라벨 리스트

        public DataGridChart2()
        {
            InitializeComponent();

            // 학생 데이터 생성
            Students = new ObservableCollection<Student>
            {
                new Student { Name = "Song", Math = 80, Science = 90, English = 85, History = 70 },
                new Student { Name = "Park", Math = 75, Science = 85, English = 88, History = 90 },
                new Student { Name = "Choi", Math = 92, Science = 78, English = 80, History = 86 },
                new Student { Name = ":ee", Math = 60, Science = 72, English = 75, History = 85 }
            };

            ChartValues = new ChartValues<double>();
            XLabels = new List<string> { "Math", "Science", "English", "History" };  // 과목 리스트

            DataContext = this;

            
            DataGridExample.SelectedCellsChanged += DataGridExample_SelectedCellsChanged;
        }

       
        private void DataGridExample_SelectedCellsChanged(object sender, System.Windows.Controls.SelectedCellsChangedEventArgs e)
        {
            ChartValues.Clear();

            
            foreach (var cell in DataGridExample.SelectedCells)
            {
                if (cell.Column.DisplayIndex >= 1 && cell.Column.DisplayIndex <= 4) // Math ~ History 열
                {
                    var student = (Student)cell.Item;
                    double value = 0;

                   
                    switch (cell.Column.Header.ToString())
                    {
                        case "Math":
                            value = student.Math;
                            break;
                        case "Science":
                            value = student.Science;
                            break;
                        case "English":
                            value = student.English;
                            break;
                        case "History":
                            value = student.History;
                            break;
                    }
                    XLabels = new List<string> { "Math", "Science", "English", "History" };  // 과목 리스트
                    ChartValues.Add(value);
                }
            }

            // 차트 갱신 (XLabels는 고정된 과목 이름이므로 따로 업데이트 필요 없음)
            //LiveChart.AxisX[0].Labels = XLabels;
            
        }
    }

    // 학생 데이터를 담는 클래스
    //public class Student
    //{
    //    public string Name { get; set; }
    //    public double Math { get; set; }
    //    public double Science { get; set; }
    //    public double English { get; set; }
    //    public double History { get; set; }
    //}
}