﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfLiveChart
{
    /// <summary>
    /// TimerUpdateChart.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class TimerUpdateChart : Window
    {
        public TimerUpdateChart()
        {
            InitializeComponent();
            DataContext = new ChartViewModel();
        }
    }

    public class ChartViewModel
    {
        public SeriesCollection SeriesCollection { get; set; }
        public string[] Labels { get; set; } = new string[] { "Maria", "Sujan" };
        Timer timer = new Timer();
        public ChartViewModel()
        {
            ChartList();

            timer.Interval = 1000;
            timer.Elapsed += new ElapsedEventHandler(UpdateChart);
            timer.Start();
        }
        public void ChartList()
        {
            var leftChart = new ChartValues<int>();
            var rightChart = new ChartValues<int>();

            leftChart.Add(20);
            leftChart.Add(40);
            rightChart.Add(10);
            rightChart.Add(25);

            SeriesCollection = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title = "2021",
                    Values = leftChart
                }
            };
            SeriesCollection.Add(new ColumnSeries
            {
                Title = "2022",
                Values = rightChart
            });
        }
        public void UpdateChart(object source, ElapsedEventArgs e)
        {
            Random rd = new Random();
            int randomNum_1 = rd.Next(30);
            int randomNum_2 = rd.Next(30);
            int randomNum_3 = rd.Next(30);
            int randomNum_4 = rd.Next(30);

            var randomLeftChart = new ChartValues<object>();
            var randomRightChart = new ChartValues<object>();
            DispatcherService.Invoke((System.Action)(() =>
            {
                foreach (var chartCollection in SeriesCollection)
                {
                    chartCollection.Values.Clear();
                    if (chartCollection.Title == "2021")
                    {
                        chartCollection.Values.Add(randomNum_1);
                        chartCollection.Values.Add(randomNum_2);

                    }
                    else
                    {
                        chartCollection.Values.Add(randomNum_3);
                        chartCollection.Values.Add(randomNum_4);
                    }
                }
            }));

        }
        public static class DispatcherService
        {
            public static void Invoke(Action action)
            {
                Dispatcher dispatchObject = Application.Current != null ? Application.Current.Dispatcher : null;
                if (dispatchObject == null || dispatchObject.CheckAccess())
                    action();
                else
                    dispatchObject.Invoke(action);
            }
        }
    }
}
