﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfLiveChart
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class LiveChartColumnSeries : Window
    {
        public SeriesCollection SeriesData { get; private set; }
        public string[] XLabel { get; set; }
        public Func<int, string> Values { get; set; }

        public LiveChartColumnSeries()
        {
            InitializeComponent();
            SeriesData = new SeriesCollection {
                new ColumnSeries  // ColumnSeries 는 막대그래프, LineSeries 는 선 그래프
                {
                  Title = "실험1",
                  Values = new ChartValues<int> { 33, 45, 47, 34, 49 }
                },
                new ColumnSeries
                {
                  Title = "실험2",
                  Values = new ChartValues<int> { 35, 46, 42, 37, 48 }
                },
                new ColumnSeries
                {
                  Title = "실험3",
                  Values = new ChartValues<int> { 38, 47, 46, 39, 47}
                },
                new ColumnSeries
                {
                  Title = "실험4",
                  Values = new ChartValues<int> { 38, 43, 44, 46, 45}
                }
              };
            XLabel = new string[] { "Kang", "Kim", "Cho", "Ko", "Song" };
            Values = value => value.ToString("N");

            DataContext = this; // Data binding 할때 필요함
        }
    }
}
