﻿using LiveCharts.Wpf;
using LiveCharts;
using System.Windows;


namespace WpfLiveChart
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public SeriesCollection Product { get; set; }
        LineSeries series1;
        LineSeries series2;
        public string[] Labels { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            // SeriesCollection 생성 및 데이터 추가
            Product = new SeriesCollection();

            series1 = new LineSeries
            {
                Title = "2023",
                Values = new ChartValues<double> { 10, 50, 39, 50, 42, 33 },
                PointGeometry = DefaultGeometries.Diamond,
                PointGeometrySize = 20

            };

            series2 = new LineSeries
            {
                Title = "2024",
                Values = new ChartValues<double> { 11, 56, 42, 48, 48, 43},         
            };
           

            Product.Add(series1);
            Product.Add(series2);

            // X축 라벨 설정           
            Labels = new[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun"};
            // 데이터 바인딩
            DataContext = this;
        }
    }
}


//Labels = new[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
//, "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" 



/*
 
public partial class MainWindow : Window
    {
        public SeriesCollection ProductCollection { get; set; }
        public string[] Labels { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            // SeriesCollection 생성 및 데이터 추가
            ProductCollection = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "2023",
                    Values = new ChartValues<double> { 10, 50, 39, 50, 42, 33, 56, 43, 58, 24, 47, 51 }
                },
                new LineSeries
                {
                    Title = "2024",
                    Values = new ChartValues<double> { 11, 56, 42, 48, 48, 43, 46, 53, 52, 44, 49, 50}
                }
            };

            // X축 라벨 설정
            //Labels = new[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
            Labels = new[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
            // 데이터 바인딩
            DataContext = this;
        }
    }
 */