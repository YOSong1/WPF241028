﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfLiveChart
{
    /// <summary>
    /// DataGridChart3.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DataGridChart3 : Window
    {
        public ObservableCollection<Student> Students { get; set; }
        public ChartValues<double> MathChartValues { get; set; }
        public ChartValues<double> ScienceChartValues { get; set; }
        public ChartValues<double> EnglishChartValues { get; set; }
        public ChartValues<double> HistoryChartValues { get; set; }
        public List<string> XLabels { get; set; }  // X축 라벨 리스트

        public DataGridChart3()
        {
            InitializeComponent();

            // 학생 데이터 생성
            Students = new ObservableCollection<Student>
            {
                new Student { Name = "Song", Math = 80, Science = 90, English = 85, History = 70 },
                new Student { Name = "Park", Math = 75, Science = 85, English = 88, History = 90 },
                new Student { Name = "Choi", Math = 92, Science = 78, English = 80, History = 86 },
                new Student { Name = ":ee", Math = 60, Science = 72, English = 75, History = 85 }
            };

            MathChartValues = new ChartValues<double>();
            ScienceChartValues = new ChartValues<double>();
            EnglishChartValues = new ChartValues<double>();
            HistoryChartValues = new ChartValues<double>();

            XLabels = new List<string>();

            // 데이터와 축 설정은 창 로드가 완료된 후 설정
            this.Loaded += OnWindowLoaded;
        }

        private void OnWindowLoaded(object sender, RoutedEventArgs e)
        {
            // 차트 축과 데이터 초기화
            if (LiveChart.AxisX == null || LiveChart.AxisX.Count == 0)
            {
                LiveChart.AxisX.Add(new Axis { Title = "Students", Labels = XLabels });
            }

            // DataContext 설정
            DataContext = this;

            // DataGrid Cell 선택이 변경될 때 이벤트 처리
            DataGridExample.SelectedCellsChanged += DataGridExample_SelectedCellsChanged;
        }

        private void DataGridExample_SelectedCellsChanged(object sender, System.Windows.Controls.SelectedCellsChangedEventArgs e)
        {
            if (!DataGridExample.SelectedCells.Any())
            {
                MathChartValues.Clear();
                ScienceChartValues.Clear();
                EnglishChartValues.Clear();
                HistoryChartValues.Clear();
                XLabels.Clear();
                return;
            }

            MathChartValues.Clear();
            ScienceChartValues.Clear();
            EnglishChartValues.Clear();
            HistoryChartValues.Clear();
            XLabels.Clear();

            var selectedStudents = DataGridExample.SelectedCells
                .Select(cell => (Student)cell.Item)
                .Distinct();

            foreach (var student in selectedStudents)
            {
                XLabels.Add(student.Name);

                MathChartValues.Add(student.Math);
                ScienceChartValues.Add(student.Science);
                EnglishChartValues.Add(student.English);
                HistoryChartValues.Add(student.History);
            }

            // XLabels가 null 또는 비어 있을 경우 차트 갱신 방지
            if (XLabels != null && XLabels.Any())
            {
                LiveChart.AxisX[0].Labels = XLabels;
            }
        }
    }

        // 학생 데이터를 담는 클래스
    public class Student
    {
        public string Name { get; set; }
        public double Math { get; set; }
        public double Science { get; set; }
        public double English { get; set; }
        public double History { get; set; }
    }
}