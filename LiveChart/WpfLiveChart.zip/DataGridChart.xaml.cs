﻿using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfLiveChart
{
    /// <summary>
    /// PieChart.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DataGridChart : Window
    {
        public ObservableCollection<DataItem> Data { get; set; }
        public ChartValues<double> ChartValues { get; set; }
        public List<string> Xlabel;
        public DataGridChart()
        {
            InitializeComponent();

            Data = new ObservableCollection<DataItem>
            {
                new DataItem { Category = "A", Value = 10 },
                new DataItem { Category = "B", Value = 20 },
                new DataItem { Category = "C", Value = 30 },
                new DataItem { Category = "D", Value = 40 }
            };

            ChartValues = new ChartValues<double>();

            DataContext = this;

            // DataGrid Cell 선택이 변경될 때 이벤트 처리
            DataGridExample.SelectedCellsChanged += DataGridExample_SelectedCellsChanged;
        }

        // DataGrid에서 선택된 셀의 값을 차트에 반영하는 함수
        private void DataGridExample_SelectedCellsChanged(object sender, System.Windows.Controls.SelectedCellsChangedEventArgs e)
        {            
            ChartValues.Clear();
            foreach (var cell in DataGridExample.SelectedCells)
            {
                if (cell.Column.DisplayIndex == 1) // 두 번째 열(Values)에서만 데이터를 차트에 반영
                {
                    var value = ((DataItem)cell.Item).Value;
                    ChartValues.Add(value);                   
                }
            }          
        }
    }

    // 데이터를 담는 클래스
    public class DataItem
    {
        public string Category { get; set; }
        public double Value { get; set; }
    }
}