﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfLiveChart
{
    /// <summary>
    /// LiveChartLineSeries.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class LiveChartLineSeries : Window
    {      

        public SeriesCollection SeriesData { get; private set; }
        public string[] XLabel { get; set; }
        public Func<int, string> Values { get; set; }

        public LiveChartLineSeries()
        {
            InitializeComponent();
            SeriesData = new SeriesCollection {
            new LineSeries 
            {
              Title = "실험1",
              Values = new ChartValues<int> { 33, 45, 47, 34, 49 }
            },
            new LineSeries
            {
              Title = "실험2",
              Values = new ChartValues<int> { 35, 46, 42, 37, 48 }
            },
            new LineSeries
            {
              Title = "실험3",
              Values = new ChartValues<int> { 38, 47, 46, 39, 47}
            },
            new LineSeries
            {
              Title = "실험4",
              Values = new ChartValues<int> { 38, 43, 44, 46, 45}
            }
          };
            XLabel = new string[] { "hong", "Kang", "Cho", "Lee", "Song" };
            Values = value => value.ToString("N");

            DataContext = this; // Data binding 할때 필요함
        }
    }
}
